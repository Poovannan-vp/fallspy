let map;
let marker;
let selectedPatientId = null;
let locationHistory = [];
let mapInitialized = false;

document.addEventListener('DOMContentLoaded', () => {
    const patientSelect = document.getElementById('gpsPatientSelect');
    const refreshBtn = document.getElementById('refreshBtn');
    const viewInMapsBtn = document.getElementById('viewInMapsBtn');

    loadPatients();
    initMap();

    patientSelect.addEventListener('change', (e) => {
        selectedPatientId = e.target.value;
        if (selectedPatientId) {
            startLocationTracking(selectedPatientId);
        } else {
            stopLocationTracking();
            resetMap();
        }
    });

    refreshBtn.addEventListener('click', () => {
        if (selectedPatientId) {
            updatePatientLocation(selectedPatientId);
        }
    });

    viewInMapsBtn.addEventListener('click', () => {
        if (marker && marker.getPosition()) {
            const pos = marker.getPosition();
            window.open(`https://www.google.com/maps?q=${pos.lat()},${pos.lng()}`);
        }
    });

    setInterval(() => {
        if (selectedPatientId && mapInitialized) {
            updatePatientLocation(selectedPatientId);
        }
    }, 10000);
});

function initMap() {
    const defaultPosition = { lat: 13.0085, lng: 80.0035 };
    map = new google.maps.Map(document.getElementById('map'), {
        center: defaultPosition,
        zoom: 15
    });

    // Place default marker
    marker = new google.maps.Marker({
        position: defaultPosition,
        map: map,
        title: 'Default Location'
    });

    mapInitialized = true;
}

async function loadPatients() {
    try {
        const snapshot = await db.collection('patients').get();
        const select = document.getElementById('gpsPatientSelect');
        select.innerHTML = '<option value="">Select a patient</option>';

        snapshot.forEach(doc => {
            const option = document.createElement('option');
            option.value = doc.id;
            option.textContent = doc.data().name;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading patients:', error);
    }
}

function startLocationTracking(patientId) {
    if (marker) marker.setMap(null);
    updatePatientLocation(patientId);
}

function stopLocationTracking() {
    if (marker) marker.setMap(null);
}

function resetMap() {
    if (map) {
        map.setCenter({ lat: 13.0085, lng: 80.0035 });
        map.setZoom(15);
    }
}

async function updatePatientLocation(patientId) {
    try {
        const doc = await db.collection('patients').doc(patientId).get();
        if (!doc.exists) return;

        const patient = doc.data();
        const locationRef = realtimeDb.ref(`locations/${patientId}`);

        locationRef.once('value', (snapshot) => {
            const location = snapshot.val();
            if (location && location.lat && location.lng) {
                const pos = new google.maps.LatLng(location.lat, location.lng);

                locationHistory.unshift({
                    timestamp: new Date().toLocaleString(),
                    lat: location.lat,
                    lng: location.lng
                });
                updateLocationHistory();

                if (marker) {
                    marker.setPosition(pos);
                    marker.setTitle(patient.name);
                } else {
                    marker = new google.maps.Marker({
                        position: pos,
                        map: map,
                        title: patient.name
                    });
                }

                map.setCenter(pos);
                map.setZoom(15);
            } else {
                // If no location found, fall back to default
                const defaultPos = new google.maps.LatLng(13.0085, 80.0035);
                if (!marker) {
                    marker = new google.maps.Marker({
                        position: defaultPos,
                        map: map,
                        title: 'Default'
                    });
                } else {
                    marker.setPosition(defaultPos);
                    marker.setTitle('Default');
                }
                map.setCenter(defaultPos);
            }
        });
    } catch (error) {
        console.error('Error updating patient location:', error);
    }
}

function updateLocationHistory() {
    const historyElement = document.getElementById('locationHistory');
    historyElement.innerHTML = '';

    const recentLocations = locationHistory.slice(0, 5);

    recentLocations.forEach(loc => {
        const div = document.createElement('div');
        div.className = 'location-entry';
        div.innerHTML = `
            <p><strong>${loc.timestamp}</strong></p>
            <p>Lat: ${loc.lat.toFixed(4)}, Lng: ${loc.lng.toFixed(4)}</p>
        `;
        historyElement.appendChild(div);
    });
}
